package com.example.homework_1android_2.adapteres

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.homework_1android_2.data.Data
import com.example.homework_1android_2.databinding.ItemBinding
import com.example.homework_1android_2.fragmentes.MovieFragment as MovieFragment1

class MovieAdapter(private val onItemClick: (name: Data) -> Unit) :
    RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    private var list: List<Data> = ArrayList()

    @SuppressLint("NotifyDataSetChanged")
    fun setList(list: List<Data>) {
        this.list = list
        notifyDataSetChanged()
    }

    inner class MovieViewHolder(private val binding: ItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            itemView.setOnClickListener {
                onItemClick(list[adapterPosition])

            }
        }

        fun onBind(data: Data) {
            binding.titleName.text = data.titleName
            binding.image.let { Glide.with(it).load(data.image).into(binding.image) }

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        return MovieViewHolder(
            ItemBinding.inflate(
                LayoutInflater.from(
                    parent.context
                ), parent,
                false
            )
        )

    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        holder.onBind(list[position])
    }


}