package com.example.homework_1android_2.data

data class Data(val image : String? = null,
                val titleName : String? = null,
                val detailName : String? = null)
